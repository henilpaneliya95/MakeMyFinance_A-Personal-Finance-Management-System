import { Link, useLocation } from "react-router-dom"
import { LayoutDashboard, CreditCard, Wallet, Briefcase, PiggyBank, TrendingDown, Target, BarChart, BrainCircuit, Cpu, Star, LogOut, Settings, User, HelpCircle, BadgeDollarSign, TrendingUp, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

const navItems = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { name: "Transactions", icon: CreditCard, path: "/transactions" },
  { name: "Budgets", icon: Wallet, path: "/budgets" },
  { name: "Portfolio", icon: Briefcase, path: "/portfolio" },
  { name: "Savings", icon: PiggyBank, path: "/savings" },
  { name: "Debt Tracker", icon: TrendingDown, path: "/debt" },
  { name: "Goals", icon: Target, path: "/goals" },
  { name: "Analytics", icon: BarChart, path: "/analytics" },
  { name: "AI Insights", icon: BrainCircuit, path: "/ai-insights" },
  { name: "Simulator", icon: Cpu, path: "/simulator" },
  { name: "Reviews", icon: Star, path: "/reviews" },
]

const supportItems = [
  { name: "Accounts", icon: BadgeDollarSign, path: "/accounts" },
  { name: "Settings", icon: Settings, path: "/settings" },
  { name: "Need Help?", icon: HelpCircle, path: "/help" },
]

export function Sidebar({ sidebarOpen, setSidebarOpen, handleLogout }) {
  const location = useLocation()
  const currentPath = location.pathname

  return (
    <>
      {/* Mobile Sidebar Overlay: This creates a semi-transparent overlay when the sidebar is open on small screens. */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true" // Indicate to screen readers that this is decorative
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white border-r border-gray-200 shadow-xl transform transition-transform duration-300 ease-in-out",
          // On large screens (lg), the sidebar is static and always visible.
          // On smaller screens, it slides in/out based on `sidebarOpen` state.
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header Section */}
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  FinTrack AI
                </span>
              </div>
              {/* Close button for mobile sidebar */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(false)}
                className="lg:hidden" // Only visible on small screens
                aria-label="Close sidebar"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <p className="text-sm text-gray-500 mt-1">Smarter Money Decisions</p>
          </div>

          {/* Navigation Section */}
          <ScrollArea className="flex-1 px-4 py-6">
            <nav className="space-y-2">
              {navItems.map(({ name, icon: Icon, path }) => {
                const isActive = currentPath === path
                return (
                  <Link to={path} key={name} onClick={() => setSidebarOpen(false)}>
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-sm font-medium px-3 py-2 rounded-xl transition-all duration-200",
                        isActive
                          ? "bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 shadow-sm"
                          : "text-gray-700 hover:bg-gray-100 hover:text-gray-900",
                      )}
                      aria-current={isActive ? "page" : undefined} // ARIA for current page
                    >
                      <Icon className="w-5 h-5 mr-3" />
                      <span>{name}</span>
                    </Button>
                  </Link>
                )
              })}

              <div className="my-4 border-t border-gray-200" />
              <p className="text-xs text-gray-400 px-3 uppercase tracking-wide font-semibold mb-2">Settings</p>

              {supportItems.map(({ name, icon: Icon, path }) => {
                const isActive = currentPath === path
                return (
                  <Link to={path} key={name} onClick={() => setSidebarOpen(false)}>
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-sm font-medium px-3 py-2 rounded-xl transition-all duration-200",
                        isActive
                          ? "bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 shadow-sm"
                          : "text-gray-700 hover:bg-gray-100 hover:text-gray-900",
                      )}
                      aria-current={isActive ? "page" : undefined}
                    >
                      <Icon className="w-5 h-5 mr-3" />
                      <span>{name}</span>
                    </Button>
                  </Link>
                )
              })}
            </nav>
          </ScrollArea>

          {/* User Profile Section */}
          <div className="p-4 border-t border-gray-100 space-y-3">
            <div className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">
                  {localStorage.getItem("username") || "User"}
                </p>
                <p className="text-xs text-gray-500 truncate">Premium Member</p>
              </div>
            </div>

            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full justify-start text-red-600 hover:bg-red-50 hover:text-red-700 border-red-200 bg-transparent"
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </aside>
    </>
  )
}
