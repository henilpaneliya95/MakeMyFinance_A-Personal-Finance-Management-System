import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Layout from "./components/Layout"
import Transactions from "./pages/Transactions"
import Homepage from "./pages/Homepage"
import Savings from "./pages/Savings"
import Analytics from "./pages/Analytics"
import Reviews from "./pages/Reviews"
import Accounts from "./pages/Accounts"
import Login from "./pages/Login"
import Signup from "./pages/Signup"
import FinancialDashboard from "./pages/Dashboard"
import APIC from "./pages/APIC"
import HomePage2 from "./pages/homepage2"
import EnhancedPortfolio from "./pages/Portfolio"
import EnhancedGoals from "./pages/Goals"
import EnhancedDebtTracker from "./pages/Debttracker"
import EnhancedBudgets from "./pages/Budgets"
import Simulator from "./pages/Simulator"
import NeedHelp from "./pages/Needhelp"
import EnhancedSettings from "./pages/Settings"
import AIInsights from "./pages/Aiinsights"
import ReceiptScanner from "./pages/ReceiptScanner"
import AIHelp from "./pages/AIHelp"
import Help from "./pages/Help"
import ContactUs from "./pages/contectus"

function App() {
  return (
    <Router>
      <Routes>
        {/* Pages without layout */}
        <Route path="/" element={<HomePage2 />} />
        <Route path="/homepage" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Pages with layout */}
        <Route
          path="/apic"
          element={
            <Layout title="API Configuration">
              <APIC />
            </Layout>
          }
        />
        <Route
          path="/dashboard"
          element={
            <Layout
              title="Financial Dashboard"
              subtitle={new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
            >
              <FinancialDashboard />
            </Layout>
          }
        />
        <Route
          path="/transactions"
          element={
            <Layout title="Transactions" subtitle="Manage your income and expenses">
              <Transactions />
            </Layout>
          }
        />
        <Route
          path="/savings"
          element={
            <Layout title="Savings" subtitle="Track your savings goals">
              <Savings />
            </Layout>
          }
        />
        <Route
          path="/analytics"
          element={
            <Layout title="Analytics" subtitle="Financial insights and reports">
              <Analytics />
            </Layout>
          }
        />
        <Route
          path="/reviews"
          element={
            <Layout title="Reviews" subtitle="Review your financial performance">
              <Reviews />
            </Layout>
          }
        />
        <Route
          path="/accounts"
          element={
            <Layout title="Accounts" subtitle="Manage your financial accounts">
              <Accounts />
            </Layout>
          }
        />
        <Route
          path="/settings"
          element={
            <Layout title="Settings" subtitle="Customize your preferences">
              <EnhancedSettings />
            </Layout>
          }
        />
        <Route
          path="/budgets"
          element={
            <Layout title="Budgets" subtitle="Plan and track your spending">
              <EnhancedBudgets />
            </Layout>
          }
        />
        <Route
          path="/debt"
          element={
            <Layout title="Debt Tracker" subtitle="Monitor and manage your debts">
              <EnhancedDebtTracker />
            </Layout>
          }
        />
        <Route
          path="/goals"
          element={
            <Layout title="Financial Goals" subtitle="Set and achieve your targets">
              <EnhancedGoals />
            </Layout>
          }
        />
        <Route
          path="/portfolio"
          element={
            <Layout title="Investment Portfolio" subtitle="Track your investments">
              <EnhancedPortfolio />
            </Layout>
          }
        />
        <Route
          path="/simulator"
          element={
            <Layout title="Financial Simulator" subtitle="Plan your financial future">
              <Simulator />
            </Layout>
          }
        />
        <Route
          path="/help"
          element={
            <Layout title="Help Center" subtitle="Get assistance and support">
              <NeedHelp />
            </Layout>
          }
        />
        <Route
          path="/ai-insights"
          element={
            <Layout title="AI Insights" subtitle="Smart financial recommendations">
              <AIInsights />
            </Layout>
          }
        />
        <Route
          path="/scan"
          element={
            <Layout title="Receipt Scanner" subtitle="Scan and digitize receipts">
              <ReceiptScanner />
            </Layout>
          }
        />
        <Route
          path="/aihelp"
          element={
            <Layout title="AI Assistant" subtitle="Get AI-powered financial help">
              <AIHelp />
            </Layout>
          }
        />
        <Route
          path="/help2"
          element={
            <Layout title="Help & Support" subtitle="Frequently asked questions">
              <Help />
            </Layout>
          }
        />
        <Route
          path="/contectus"
          element={
            <Layout title="Contact Us" subtitle="Get in touch with our team">
              <ContactUs />
            </Layout>
          }
        />
      </Routes>
    </Router>
  )
}

export default App
